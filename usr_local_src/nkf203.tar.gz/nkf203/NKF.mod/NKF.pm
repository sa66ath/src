## Copyright (C) 1996,1998
## Copyright (C) 2002
## $BO"Mm@h!'(B $BN05eBg3X>pJs9)3X2J(B $B2OLn(B $B??<#(B  mime/X0208 support
## $B!J(BE-Mail Address: kono@ie.u-ryukyu.ac.jp$B!K(B
## $BO"Mm@h!'(B COW for DOS & Win16 & Win32 & OS/2
## $B!J(BE-Mail Address: GHG00637@niftyserve.or.p$B!K(B
##    
##    $B$3$N%=!<%9$N$$$+$J$kJ#<L!$2~JQ!$=$@5$b5vBz$7$^$9!#$?$@$7!"(B
##    $B$=$N:]$K$O!"C/$,9W8%$7$?$r<($9$3$NItJ,$r;D$9$3$H!#(B
##    $B:FG[I[$d;(;o$NIUO?$J$I$NLd$$9g$o$;$bI,MW$"$j$^$;$s!#(B
##    $B1DMxMxMQ$b>e5-$KH?$7$J$$HO0O$G5v2D$7$^$9!#(B
##    $B%P%$%J%j$NG[I[$N:]$K$O(Bversion message$B$rJ]B8$9$k$3$H$r>r7o$H$7$^$9!#(B
##    $B$3$N%W%m%0%i%`$K$D$$$F$OFC$K2?$NJ]>Z$b$7$J$$!"0-$7$+$i$:!#(B
##    
##    Everyone is permitted to do anything on this program
##    including copying, modifying, improving, 
##    as long as you don't try to pretend that you wrote it.
##    i.e., the above copyright notice has to appear in all copies.  
##    Binar y distribution requires original version messages.
##    You don't have to ask before copying, redistribution or publishing.
##    THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE.


package NKF;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;
require DynaLoader;

@ISA = qw(Exporter DynaLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
	nkf	
);
$VERSION = '2.00';

bootstrap NKF $VERSION;

# Preloaded methods go here.

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

NKF - Perl extension for Network Kanji Filter 

=head1 SYNOPSIS

  use NKF;
  $output = nkf("-s",$input);

=head1 DESCRIPTION

This is a Perl Extension version of nkf (Netowrk Kanji Filter ) 1.7.
It converts the last argument and return converted result. Conversion
details are specified by flags before the last argument.

Flags:

C<b,u      Output is bufferred (DEFAULT),Output is unbufferred>

C<j,s,e    Outout code is JIS 7 bit (DEFAULT), Shift JIS, AT&T JIS (EUC)>

C<J,S,E    Input assumption is JIS 7 bit , Shift JIS, AT&T JIS (EUC)>

C<t        no conversion>

C<i_       Output sequence to designate JIS-kanji (DEFAULT B)>

C<o_       Output sequence to designate ASCII (DEFAULT B)>

C<r        {de/en}crypt ROT13/47>

C<m[BQ]    MIME decode [B:base64 stream,Q:quoted stream]>

C<l        ISO8859-1 (Latin-1) support>

C<f        Folding: C<-f60> or C<-f>>

C<Z[0-2]   Convert X0208 alphabet to ASCII  1: Kankaku to space,2: 2 spaces>

C<X,x      Assume X0201 kana in MS-Kanji, C<-x> preserves X0201>

C<B[0-2]   Broken input  0: missing ESC,1: any X on ESC-[($]-X,2: ASCII on NL>

C<d,c      Delete \r in line feed, Add \r in line feed>


C<m0 No MIME decode.>

C<M MIME encode. Header style. All ASCII code and control characters are intact.>

C<MB MIME encode.  Base64 stream. Kanji conversion is performed before encoding, so this cannot be used as a picture encoder.>

C<l Input and output code is ISO8859-1 (Latin-1) and ISO-2022-JP.>

C<L[wmu] new line mode>

C<    -Lu   unix (LF) >

C<    -Lw   windows (CRLF) >

C<    -Lm   mac (CR) >

C< --fj,--unix,--mac,--msdos, --windows convert for these system>

C< --jis,--euc,--sjis,--mime,--base64  convert for named code>

C< --jis-input,--euc-input,--sjis-input,--mime-input,--base64-input assume input system>

C< -- ignore rest of -option>

C< --help>

C< --version>

=head1 AUTHOR

Network Kanji Filter Version 1.9 (2/0002/Shinji Kono) 
Copyright (C) 1987, FUJITSU LTD. (I.Ichikawa),1998 S. Kono, COW

=head1 SEE ALSO

perl(1).   nkf(1)

=cut
